#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <limits.h>

#define MAX_N 1000
#define MAX_SAMPLE 1000000
#define HIST_SIZE 100

// 卡方临界值简化计算
double chi2_table(int df) {
    switch(df) {
        case 1: return 3.841;
        case 2: return 5.991;
        case 5: return 11.070;
        default: return df + sqrt(2*df); // 近似估计
    }
}

// 均匀分布随机数
int rand_modN(int N) {
    return rand() % N;
}

// 正态分布随机数（Box-Muller，标准正态）
double generate_std_normal() {
    static int has_spare = 0;
    static double spare;
    
    if (has_spare) {
        has_spare = 0;
        return spare;
    }
    
    double u, v, s;
    do {
        u = 2.0 * rand() / (RAND_MAX + 1.0) - 1.0; // [-1, 1]
        v = 2.0 * rand() / (RAND_MAX + 1.0) - 1.0; // [-1, 1]
        s = u * u + v * v;
    } while (s >= 1.0 || s == 0.0);
    
    double mag = sqrt(-2.0 * log(s) / s);
    double z0 = u * mag;
    spare = v * mag;
    has_spare = 1;
    
    return z0;
}
// 生成0到N-1的正态分布整数
int* generate_normal_integers(int N, int sample_count) {
    if (N <= 0 || sample_count <= 0) {
        return NULL;
    }
    
    // 分配内存存储结果
    int* results = (int*)malloc(sample_count * sizeof(int));
    if (!results) {
        return NULL;
    }
    
    // 计算中心点（均值）
    double center = (N - 1) / 2.0;
    
    // 计算标准差（覆盖约95%的区间）
    double std_dev = (N > 1) ? (center / 2.0) : 0.0;
    
    for (int i = 0; i < sample_count; i++) {
        // 生成正态分布值
        double normal_val = center + std_dev * generate_std_normal();
        
        // 转换为整数并限制在0到N-1范围内
        int val = (int)round(normal_val);
        if (val < 0) val = 0;
        if (val >= N) val = N - 1;
        
        results[i] = val;
    }
    
    return results;
}
// 频率分布测试
void frequency_test(int *data, int N, int sample) {
    int *count = calloc(N, sizeof(int));
    for (int i = 0; i < sample; ++i) count[data[i]]++;

    // 1.1 直接计数法
    printf("\n[1] 直接计数法:\n");
    for (int i = 0; i < N; ++i)
        printf("%3d: %8d  概率: %.6f\n", i, count[i], count[i]/(double)sample);

    // 1.2 分段直方图法
    printf("\n[2] 分段直方图法:\n");
    int seg = N < 10 ? N : 10;
    int seg_size = N / seg;
    for (int s = 0; s < seg; ++s) {
        int sum = 0;
        for (int i = s*seg_size; i < (s+1)*seg_size && i < N; ++i)
            sum += count[i];
        printf("区间[%3d-%3d]: %8d  概率: %.6f\n",
               s*seg_size, (s+1)*seg_size-1, sum, sum/(double)sample);
    }

    // 1.3 熵测试
    printf("\n[3] 熵测试:\n");
    double entropy = 0.0;
    for (int i = 0; i < N; i++) {
        if (count[i] > 0) {
            double p = (double)count[i] / sample;
            entropy -= p * log2(p);
        }
    }
    double max_entropy = log2(N);
    printf("计算熵 = %.6f bits\n", entropy);
    printf("最大熵 = %.6f bits (%.2f%%)\n", max_entropy, 100*entropy/max_entropy);

    // 1.4 卡方检验
    double expect = sample / (double)N;
    double chi2 = 0;
    for (int i = 0; i < N; ++i)
        chi2 += (count[i] - expect) * (count[i] - expect) / expect;
    printf("\n[4]卡方检验:\n");
    printf("卡方统计量: %.3f，自由度: %d\n", chi2, N-1);
    printf("（参考：95%%置信度临界值为%.2f）\n", chi2_table(N-1));

    // 1.5 最大/最小频率差法
    printf("\n[5] 最大/最小频率差法:\n");
    int maxc = count[0], minc = count[0];
    for (int i = 1; i < N; ++i) {
        if (count[i] > maxc) maxc = count[i];
        if (count[i] < minc) minc = count[i];
    }
    printf("最大频率: %d, 最小频率: %d, 差值: %d\n", maxc, minc, maxc-minc);

    free(count);
}

// 间隔分布测试
void interval_test(int *data, int N, int sample) {
    int *last = malloc(N * sizeof(int));
    int (*interval_hist)[HIST_SIZE] = calloc(N, sizeof(int[HIST_SIZE]));
    int *interval_sum = calloc(N, sizeof(int));
    double *interval_sqsum = calloc(N, sizeof(double));
    int *interval_cnt = calloc(N, sizeof(int));
    int *global_hist = calloc(HIST_SIZE, sizeof(int));
    int *max_interval = calloc(N, sizeof(int));
    int *min_interval = malloc(N * sizeof(int));
    for (int i = 0; i < N; ++i) { last[i] = -1; min_interval[i] = sample; }

    for (int i = 0; i < sample; ++i) {
        int v = data[i];
        if (last[v] != -1) {
            int interval = i - last[v];
            int hist_idx = interval < HIST_SIZE ? interval : HIST_SIZE-1;
            interval_hist[v][hist_idx]++;
            global_hist[hist_idx]++;
            interval_sum[v] += interval;
            interval_sqsum[v] += interval*interval;
            interval_cnt[v]++;
            if (interval > max_interval[v]) max_interval[v] = interval;
            if (interval < min_interval[v]) min_interval[v] = interval;
        }
        last[v] = i;
    }

    // 2.1 直接间隔计数法
    printf("\n[1] 直接间隔计数法:\n");
    printf("值\t间隔1-9分布\n");
    for (int i = 0; i < N; ++i) {
        printf("%3d: ", i);
        for (int j = 1; j < 10; ++j)
            printf("%2d:%4d ", j, interval_hist[i][j]);
        printf("...\n");
    }

    // 2.2 平均间隔法
    printf("\n[2] 平均间隔法:\n");
    for (int i = 0; i < N; ++i)
        printf("%3d: 平均间隔: %.2f%s\n", i,
               interval_cnt[i] ? interval_sum[i]/(double)interval_cnt[i] : 0,
               interval_cnt[i] ? "" : " (无间隔数据)");

    // 2.3 间隔方差法
    printf("\n[3] 间隔方差法:\n");
    for (int i = 0; i < N; ++i) {
        if (interval_cnt[i] < 2) {
            printf("%3d: 方差: 无法计算 (间隔数<2)\n", i);
            continue;
        }
        double mean = interval_sum[i]/(double)interval_cnt[i];
        double var = interval_sqsum[i]/(double)interval_cnt[i] - mean*mean;
        printf("%3d: 方差: %.2f\n", i, var);
    }

    // 2.4 全局间隔直方图
    printf("\n[4] 全局间隔直方图:\n");
    printf("间隔\t出现次数\n");
    for (int j = 1; j < 20; ++j)
        printf("%2d\t%6d\n", j, global_hist[j]);

    // 2.5 排列测试
    int k = 3; // 默认块大小
    int num_permutations = 1;
    for (int i = 1; i <= k; i++) num_permutations *= i;
    
    int *perm_counts = calloc(num_permutations, sizeof(int));
    int total_blocks = sample / k;
    int valid_blocks = 0; // 有效块计数器
    
    if (total_blocks == 0) {
        printf("样本数不足，无法进行排列测试（需至少%d个样本）\n", k);
        free(perm_counts);
        // 释放之前分配的所有内存
        free(last);
        free(interval_hist);
        free(interval_sum);
        free(interval_sqsum);
        free(interval_cnt);
        free(global_hist);
        free(max_interval);
        free(min_interval);
        return;
    }
    
    for (int i = 0; i < total_blocks; i++) {
        int block[k];
        int start_idx = i * k;
        int has_duplicate = 0;
        
        // 填充块并检查重复值
        for (int j = 0; j < k; j++) {
            block[j] = data[start_idx + j];
            // 检查当前值是否与前面的值重复
            for (int m = 0; m < j; m++) {
                if (block[m] == block[j]) {
                    has_duplicate = 1;
                    break;
                }
            }
            if (has_duplicate) break;
        }
        
        if (has_duplicate) continue; // 跳过有重复值的块
        valid_blocks++;
        
        // 计算排列顺序（阶乘表示法）
        int order = 0;
        for (int j = 0; j < k; j++) {
            int count = 0;
            for (int m = j + 1; m < k; m++) {
                if (block[m] < block[j]) count++;
            }
            order = order * (k - j) + count;
        }
        
        if (order >= 0 && order < num_permutations) {
            perm_counts[order]++;
        }
    }
    
    printf("\n[5] 排列测试 (块大小: %d, 有效样本块数: %d):\n", k, valid_blocks);
    printf("排列ID\t出现次数\t概率\t\t期望概率\n");
    
    double expected_prob = 1.0 / num_permutations;
    for (int i = 0; i < num_permutations; i++) {
        double prob = valid_blocks ? (double)perm_counts[i] / valid_blocks : 0;
        printf("%6d\t%9d\t%9.6f\t%9.6f\n", i, perm_counts[i], prob, expected_prob);
    }
    
    // 释放所有分配的内存
    free(perm_counts);
    free(last);
    free(interval_hist);
    free(interval_sum);
    free(interval_sqsum);
    free(interval_cnt);
    free(global_hist);
    free(max_interval);
    free(min_interval);
}
void normal_distribution_test(int *data, int N, int sample) {
    // 理论值计算
    double mu_theory = (N - 1) / 2.0;  // 理论均值
    double sigma2_theory = (N * N - 1) / 12.0;  // 理论方差
    double sigma_theory = sqrt(sigma2_theory);  // 理论标准差

    // 实际值计算
    double sum = 0.0, sum_sq = 0.0;
    for (int i = 0; i < sample; i++) {
        sum += data[i];
        sum_sq += data[i] * data[i];
    }
    double mu_actual = sum / sample;  // 实际均值
    double sigma2_actual = (sum_sq / sample) - (mu_actual * mu_actual);  // 实际方差
    double sigma_actual = sqrt(sigma2_actual);  // 实际标准差

    // 频率统计（直接计数法）
    int *count = (int *)malloc(N * sizeof(int));
    for (int i = 0; i < N; i++) {
        count[i] = 0;
    }
    for (int i = 0; i < sample; i++) {
        int num = data[i];
        if (num >= 0 && num < N) {
            count[num]++;
        }
    }

    // 输出结果
    printf("\n正态分布测试 (样本数: %d, 范围: 0-%d):\n", sample, N-1);
    printf("理论值:\n");
    printf("  均值 = %.6f\n", mu_theory);
    printf("  方差 = %.6f\n", sigma2_theory);
    printf("  标准差 = %.6f\n", sigma_theory);
    printf("\n实际值:\n");
    printf("  均值 = %.6f (偏差: %.6f)\n", mu_actual, fabs(mu_actual - mu_theory));
    printf("  方差 = %.6f (偏差: %.6f)\n", sigma2_actual, fabs(sigma2_actual - sigma2_theory));
    printf("  标准差 = %.6f (偏差: %.6f)\n", sigma_actual, fabs(sigma_actual - sigma_theory));

    // 计算相对误差
    double mean_rel_error = fabs(mu_actual - mu_theory) / mu_theory * 100;
    double var_rel_error = fabs(sigma2_actual - sigma2_theory) / sigma2_theory * 100;
    printf("\n相对误差:\n");
    printf("  均值相对误差: %.2f%%\n", mean_rel_error);
    printf("  方差相对误差: %.2f%%\n", var_rel_error);

    // 输出频率统计结果（直接计数法）
    printf("\n正态分布随机数频率统计 (样本数: %d, 范围: 0-%d):\n", sample, N-1);
    for (int i = 0; i < N; i++) {
        double probability = (double)count[i] / sample;
        printf("%d:  %d 概率: %.6f\n", i, count[i], probability);
    }

    free(count);
}
// ================== 主程序 ==================
void print_menu() {
    printf("\n==== 随机数分布测试工具 ====\n");
    printf("1. 均匀分布 (rand()%%N)\n");
    printf("2. 正态分布 (Box-Muller)\n");
    printf("0. 退出\n");
}

void print_test_menu() {
    printf("\n可用测评工具：\n");
    printf("1. 频率分布测试\n");
    printf("2. 间隔分布测试\n");
    printf("0. 返回\n");
}

int main() {
    int N, sample, method, test;
    int *data;
    
    srand(time(NULL));
    
    printf("请输入N (随机数范围0~N-1, N<=1000): ");
    scanf("%d", &N);
    if (N < 2 || N > MAX_N) { printf("N不合法\n"); return 1; }
    
    printf("请输入样本数 (建议10000~1000000): ");
    scanf("%d", &sample);
    if (sample < 1000 || sample > MAX_SAMPLE) { printf("样本数不合法\n"); return 1; }
    
    data = (int*)malloc(sample * sizeof(int));
    if (!data) { printf("内存分配失败\n"); return 1; }
    
    while (1) {
        print_menu();
        printf("请选择随机数生成方法: ");
        scanf("%d", &method);
        if (method == 0) break;
        
        // 生成数据
        switch(method) {
            case 1:
                for (int i = 0; i < sample; ++i) data[i] = rand_modN(N);
                while (1) {
                    print_test_menu();
                    printf("请选择测评工具: ");
                    scanf("%d", &test);
                    if (test == 0) break;
                    switch(test) {
                        case 1: frequency_test(data, N, sample); break;
                        case 2: interval_test(data, N, sample); break;
                        default: printf("无效选择\n");
                    }
                }
                break;
            case 2:
                generate_std_normal();
                int* samples = generate_normal_integers(N, sample);
                for (int i = 0; i < sample; ++i) data[i] = samples[i];
                normal_distribution_test(data, N, sample);
                while (1) {
                    print_test_menu();
                    printf("请选择测评工具: ");
                    scanf("%d", &test);
                    if (test == 0) break;
                    switch(test) {
                        case 1:
                            frequency_test(data, N, sample);
                            break;
                        case 2: interval_test(data, N, sample); break;
                        default: printf("无效选择\n");
                    }
                }
        }
    }
    free(data);
    printf("程序结束。\n");
    return 0;
}
